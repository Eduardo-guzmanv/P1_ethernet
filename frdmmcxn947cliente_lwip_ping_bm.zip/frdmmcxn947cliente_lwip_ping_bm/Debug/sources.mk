################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_SRCS := 
C_SRCS := 
OBJ_SRCS := 
O_SRCS := 
S_SRCS := 
S_UPPER_SRCS := 
C_DEPS := 
EXECUTABLES := 
OBJS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
board \
component/gpio \
component/lists \
component/silicon_id \
component/uart \
device \
drivers/flash/src \
drivers \
drivers/mem_interface/src \
drivers/nboot/src \
drivers/runbootloader/src \
lwip/contrib/apps/ping \
lwip/port \
lwip/port/sys_arch/dynamic \
lwip/src/api \
lwip/src/core \
lwip/src/core/ipv4 \
lwip/src/core/ipv6 \
lwip/src/netif \
lwip/src/netif/ppp \
phy \
source \
startup \
utilities \

