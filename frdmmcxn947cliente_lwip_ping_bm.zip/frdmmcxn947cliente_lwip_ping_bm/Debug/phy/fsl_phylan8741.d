phy/fsl_phylan8741.o phy/fsl_phylan8741.d: ../phy/fsl_phylan8741.c \
 ../phy/fsl_phylan8741.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\component\phy/fsl_phy.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/fsl_device_registers.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/MCXN947_cm33_core0.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/core_cm33.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_version.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_compiler.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_gcc.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/mpu_armv8.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/system_MCXN947_cm33_core0.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/MCXN947_cm33_core0_features.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common_arm.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_clock.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common.h \
 C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_reset.h
../phy/fsl_phylan8741.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\component\phy/fsl_phy.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/fsl_device_registers.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/MCXN947_cm33_core0.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/core_cm33.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_version.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_compiler.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/cmsis_gcc.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\CMSIS/mpu_armv8.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/system_MCXN947_cm33_core0.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\device/MCXN947_cm33_core0_features.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common_arm.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_clock.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_common.h:
C:\Users\eduar\OneDrive\Documentos\ITESO\7mo_semestre\redes\P1_ethernet\frdmmcxn947cliente_lwip_ping_bm\drivers/fsl_reset.h:
